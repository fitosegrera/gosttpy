=======
gosttpy
=======

**Google Speech To Text for Python**

Python module for speech recognition using Google's speech recognition API.</br>  
Tested in ubuntu 13.10 with python_2.7

Dependencies
============
For LINUX - Please install the sox and simplejson with the following lines in your terminal::

    sudo  apt-get install sox 

    sudo  pip install simplejson

For OSX you need to install Homebrew first and then the dependencies (PIP already comes with python so you might want to test in your terminal to verify your version) otherwise if you haven't installed python yet please do with "sudo brew install python" as shown in the following lines::

    sudo ruby -e "$(curl -fsSL https://raw.github.com/Homebrew/homebrew/go/install)"

    sudo brew install sox

    sudo brew install python

    sudo pip install simplejson


HOW TO USE
----------
gosttPy module recieves a voice command from the user (through the microphone) and executes a google search...
It achieves this by recording a .flac audio file and uploading it to google's speech
recognition engine which converts it into readable text. The output from google is a 
JSON object with a list of posible interpretations/transcripts (translations from voice to text. **A google speech API KEY will be needed for the module to work. Please get one from the google developers wesite:** 

http://www.chromium.org/developers/how-tos/api-keys

**The JSON object looks like this:**
************************************
    {"result":[{"alternative":[{"transcript":"world","confidence":0.43871391},  {"transcript":"World"},{"transcript":"solo"},{"transcript":"solo world"},{"transcript":"so wharo"}],"final":true}],"result_index":0}

The result of this operation becomes a google search engine query that outputs 
some result related to the original voice command...

The goosttPy module allows you to choose between different outputs:

1. 'RAW' --> Google's speech API JSON object (Complete / not-parsed)raw-data

2. 'FIRST' --> Just the first transcripted version of your voice 

3. 'ALL' --> The list of all the transcripts returned by the google speech API

4. 'SEARCH' --> includes the search result returned from google 

**Example / Usage**
*******************
python code::

   from gosttpy import gosttpy # From the file goosttPy.py import the class goosttPy 

   speech = gosttpy()

   # Google API key for voice recognition (Replace the string 'YOUR-GOOGLE-SPEECH-API-KEY' with
   #your google API Key. Follow this link: http://www.chromium.org/developers/how-tos/api-keys
   apiKey = 'YOUR-GOOGLE-SPEECH-API-KEY'
   
   #returnType --> options are: 'RAW', 'FIRST', 'ALL', 'SEARCH' 
   returnType = 'FIRST'
   returnedText = speech.voiceRecognitionAndSearch(apiKey, returnType)
   print returnedText
